﻿
//AAAAA
let manoj = [75000; 48000; 120000; 190000; 300113; 92000; 36000]
let income = List.filter (fun salary -> salary > 100000) manoj
income |> printfn "%A"




//bbbbbbbb
let taxBracketInfo = 
    [|
        {| upperLimit = 49020.0; taxRate = 0.15 |}
        {| upperLimit = 98040.0; taxRate = 0.205 |}
        {| upperLimit = 151978.0; taxRate = 0.26 |}
        {| upperLimit = 216511.0; taxRate = 0.29 |}
        {| upperLimit = System.Double.MaxValue; taxRate = 0.33 |} // Use MaxValue to represent no upper limit
    |]

let calculateIndividualTax income = 
    taxBracketInfo 
    |> Array.tryFind (fun bracket -> income <= bracket.upperLimit)
    |> function
        | Some(bracket) -> income * bracket.taxRate
        | None -> income * (taxBracketInfo |> Array.last).taxRate

let employeeSalaries = [75000.0; 48000.0; 120000.0; 190000.0; 300113.0; 92000.0; 56000.0]

let employeeTaxedAmounts = employeeSalaries |> List.map calculateIndividualTax

employeeTaxedAmounts |> List.iter (printfn "Taxed Amount: %f")




//CCCCCCCCCCC
let manoj = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let incrementSalary salary = salary + 20000

let updatedSalaries = //
    manoj 
    |> List.filter (fun salary -> salary < 49020)
    |> List.map (fun salary -> (salary, incrementSalary salary))

updatedSalaries |> List.iter (fun (original, updated) ->
    printfn "Original salary: $%d, Updated salary: $%d" original updated)






//Ddddddddd
let sumFilteredSalaries salaryList lowerBound upperBound =
    salaryList
    |> List.filter (fun salary -> salary >= lowerBound && salary <= upperBound)
    |> List.fold (fun acc salary -> acc + salary) 0.0

let totalSum = sumFilteredSalaries manoj 50000.0 100000.0

printfn "The Total Sum of Salaries between $50,000 and $100,000: %f" totalSum





//Tail recursion 1
 Tail-recursive function to sum multiples of 3
let sum n =
    let rec helper (current, accumulator) =
        if current > n then accumulator
        else helper (current + 3, accumulator + current)
    helper (3, 0) 
let manoj = sum 27
printfn "The Sum of multiples of 3 up to 27: %d" manoj